(function () {
  "use strict";

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function nl2br(s) { return esc(s).replace(/\n/g, "<br>"); }

  function renderAnswer(doc) {
    var sources = (doc.sources || []).map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("");
    return (
      '<div class="answer-card">' +
      '<div class="short-answer">مختصر جواب: ' + nl2br(doc.shortAnswer) + "</div>" +
      '<div class="explain"><b>تفصیلی وضاحت:</b><br>' + nl2br(doc.explanation) + "</div>" +
      (sources ? '<div class="sources-box"><b>حوالہ جات</b><ul>' + sources + "</ul></div>" : "") +
      (doc.disputedNote ? '<div class="disputed-box"><b>مختلف فیہ مسئلہ:</b><br>' + nl2br(doc.disputedNote) + "</div>" : "") +
      (doc.needsScholar ? '<div class="scholar-banner">⚠ براہ کرم اس معاملے میں کسی مستند عالمِ دین سے رجوع کریں۔</div>' : "") +
      '<div class="small-muted" style="margin-top:.6rem;">آپ کا سوال جائزے کے بعد ویب سائٹ پر شائع کیا جا سکتا ہے۔</div>' +
      '<div class="safety-note font-ur" dir="rtl">یہ ویب سائٹ عمومی اسلامی معلومات اور رہنمائی کے لیے ہے۔ یہ حتمی فتویٰ نہیں۔ پیچیدہ یا ذاتی شرعی مسائل کے لیے مستند عالمِ دین سے رجوع کریں۔</div>' +
      "</div>"
    );
  }

  var ERROR_MSG = {
    invalid_question: "براہ کرم ایک واضح سوال لکھیں (کم از کم 5 حروف)۔",
    too_many_requests: "آپ نے بہت زیادہ سوالات پوچھ لیے ہیں۔ براہ کرم کچھ دیر بعد کوشش کریں۔",
    duplicate: "یہ سوال ابھی ابھی جمع کروایا گیا تھا۔",
    ai_unavailable: "معذرت، اس وقت AI جوابات دستیاب نہیں۔",
    ai_error: "معذرت، جواب حاصل کرنے میں مسئلہ پیش آیا۔ دوبارہ کوشش کریں۔",
  };

  function initAsk() {
    var askBtn = document.getElementById("askBtn");
    if (!askBtn) return;
    askBtn.addEventListener("click", function () {
      var qInput = document.getElementById("qInput");
      var qLang = document.getElementById("qLang");
      var qCat = document.getElementById("qCat");
      var website = document.getElementById("website");
      var statusEl = document.getElementById("askStatus");
      var answerArea = document.getElementById("answerArea");
      var question = (qInput.value || "").trim();
      if (!question) return;

      askBtn.disabled = true;
      askBtn.innerHTML = '<span class="spinner"></span> جواب تیار ہو رہا ہے...';
      statusEl.textContent = "";

      fetch("/api/ask", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          question: question,
          language: qLang ? qLang.value : "ur",
          category: qCat ? qCat.value : "",
          website: website ? website.value : "",
        }),
      })
        .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
        .then(function (res) {
          if (!res.ok) {
            statusEl.textContent = ERROR_MSG[res.data.error] || "معذرت، کچھ غلط ہو گیا۔ دوبارہ کوشش کریں۔";
            return;
          }
          answerArea.innerHTML = renderAnswer(res.data);
          qInput.value = "";
        })
        .catch(function () { statusEl.textContent = ERROR_MSG.ai_error; })
        .then(function () {
          askBtn.disabled = false;
          askBtn.textContent = "جواب حاصل کریں";
        });
    });
  }

  function qaItem(q) {
    return (
      '<a class="card qa-list-item" href="/question/' + esc(q.id) + '">' +
      '<h4 class="font-ur">' + esc(q.question.slice(0, 140)) + (q.question.length > 140 ? "…" : "") + "</h4>" +
      "<p>" + esc((q.shortAnswer || "").slice(0, 140)) + "</p>" +
      "</a>"
    );
  }

  function initSearch() {
    var input = document.getElementById("searchInput");
    var results = document.getElementById("searchResults");
    if (!input || !results) return;
    var tm;
    input.addEventListener("input", function () {
      clearTimeout(tm);
      var term = input.value.trim();
      tm = setTimeout(function () {
        if (!term) { results.innerHTML = ""; return; }
        fetch("/api/questions?q=" + encodeURIComponent(term))
          .then(function (r) { return r.json(); })
          .then(function (list) {
            results.innerHTML = list.length ? list.map(qaItem).join("") : '<div class="empty-state">کوئی نتیجہ نہیں ملا۔</div>';
          })
          .catch(function () {});
      }, 300);
    });
  }

  initAsk();
  initSearch();
})();

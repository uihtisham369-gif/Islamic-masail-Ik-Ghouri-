(function () {
  "use strict";

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // ---------- Login page ----------
  var loginBtn = document.getElementById("loginBtn");
  if (loginBtn) {
    loginBtn.addEventListener("click", function () {
      var email = document.getElementById("loginEmail").value.trim();
      var password = document.getElementById("loginPassword").value;
      var err = document.getElementById("loginError");
      err.textContent = "";
      fetch("/api/admin/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email: email, password: password }),
      })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          if (!res.ok) {
            err.textContent = res.d.error === "admin_not_configured"
              ? "Admin account is not configured on this server yet."
              : "Invalid email or password.";
            return;
          }
          window.location.href = "/admin";
        })
        .catch(function () { err.textContent = "Something went wrong. Please try again."; });
    });
  }

  // ---------- Dashboard ----------
  var root = document.getElementById("adminRoot");
  if (!root) return;

  var state = { tab: "questions", questions: [], knowledge: [], faqs: [] };

  function api(path, opts) {
    opts = opts || {};
    opts.credentials = "same-origin";
    opts.headers = Object.assign({ "content-type": "application/json" }, opts.headers || {});
    return fetch(path, opts).then(function (r) {
      if (r.status === 401) { window.location.href = "/admin/login"; throw new Error("unauthorized"); }
      return r.json().then(function (d) { return { ok: r.ok, d: d }; });
    });
  }

  function loadAll() {
    Promise.all([api("/api/admin/questions"), api("/api/admin/knowledge"), api("/api/admin/faqs")])
      .then(function (res) {
        state.questions = res[0].d || [];
        state.knowledge = res[1].d || [];
        state.faqs = res[2].d || [];
        render();
      })
      .catch(function () {});
  }

  function render() {
    var total = state.questions.filter(function (q) { return q.status !== "removed"; }).length;
    var published = state.questions.filter(function (q) { return q.status === "published"; }).length;
    var pending = state.questions.filter(function (q) { return q.status === "pending"; }).length;
    var reviewed = state.questions.filter(function (q) { return q.scholarReviewed; }).length;

    var html =
      '<div class="section-title">Admin Panel</div>' +
      '<div class="stat-row" style="margin-bottom:1rem;">' +
      statBox(total, "Total") + statBox(published, "Published") + statBox(pending, "Pending") + statBox(reviewed, "Scholar Reviewed") +
      '<button class="btn btn-outline btn-sm" id="logoutBtn" style="margin-inline-start:auto;">Log out</button>' +
      "</div>" +
      '<div class="tab-strip">' +
      ["questions", "knowledge", "faqs"].map(function (tb) {
        return '<button data-tab="' + tb + '" class="' + (state.tab === tb ? "active" : "") + '">' + tb + "</button>";
      }).join("") +
      "</div>" +
      '<div id="tabBody"></div>';
    root.innerHTML = html;

    document.getElementById("logoutBtn").onclick = function () {
      api("/api/admin/logout", { method: "POST" }).then(function () { window.location.href = "/admin/login"; });
    };
    Array.prototype.forEach.call(root.querySelectorAll("[data-tab]"), function (b) {
      b.onclick = function () { state.tab = b.getAttribute("data-tab"); render(); };
    });

    var body = document.getElementById("tabBody");
    if (state.tab === "questions") body.innerHTML = renderQuestions();
    else if (state.tab === "knowledge") body.innerHTML = renderKnowledge();
    else body.innerHTML = renderFaqs();
    wireTabEvents();
  }

  function statBox(n, label) {
    return '<div class="stat-box"><b>' + n + "</b><span>" + label + "</span></div>";
  }

  function renderQuestions() {
    var list = state.questions.slice().sort(function (a, b) { return (b.createdAt || "").localeCompare(a.createdAt || ""); });
    if (!list.length) return '<div class="empty-state">No questions yet.</div>';
    return list.map(function (q) {
      return (
        '<div class="card">' +
        '<div class="font-ur" style="font-weight:700;">' + esc(q.question) + "</div>" +
        '<div class="small-muted" style="margin:.3rem 0;">' + esc((q.shortAnswer || "").slice(0, 200)) + "</div>" +
        '<div class="meta-row">' +
        '<span class="tag font-ur">' + esc(q.category) + "</span>" +
        '<span class="tag">' + esc(q.status) + "</span>" +
        (q.scholarReviewed ? '<span class="tag">✔ Scholar Reviewed</span>' : "") +
        "</div>" +
        '<div class="meta-row" style="margin-top:.6rem;">' +
        '<button class="btn btn-outline btn-sm" data-edit="' + q.id + '">Edit</button>' +
        (q.status !== "published" ? '<button class="btn btn-primary btn-sm" data-approve="' + q.id + '">Approve &amp; Publish</button>' : "") +
        (q.status !== "rejected" ? '<button class="btn btn-outline btn-sm" data-reject="' + q.id + '">Reject</button>' : "") +
        '<button class="btn btn-outline btn-sm" data-review="' + q.id + '">' + (q.scholarReviewed ? "Unmark" : "Mark") + " Reviewed</button>" +
        '<button class="btn btn-danger btn-sm" data-delete="' + q.id + '">Delete</button>' +
        "</div></div>"
      );
    }).join("");
  }

  function renderKnowledge() {
    var html = '<button class="btn btn-primary btn-sm" id="addKnowledge" style="margin-bottom:.8rem;">+ Add Source</button>';
    if (!state.knowledge.length) return html + '<div class="empty-state">No knowledge base entries yet.</div>';
    html += state.knowledge.map(function (k) {
      return (
        '<div class="card"><div style="font-weight:700;">' + esc(k.title) + "</div>" +
        '<div class="small-muted">' + esc((k.content || "").slice(0, 220)) + "</div>" +
        '<div class="meta-row"><button class="btn btn-danger btn-sm" data-del-k="' + k.id + '">Delete</button></div></div>'
      );
    }).join("");
    return html;
  }

  function renderFaqs() {
    var html = '<button class="btn btn-primary btn-sm" id="addFaq" style="margin-bottom:.8rem;">+ Add FAQ</button>';
    if (!state.faqs.length) return html + '<div class="empty-state">No FAQs yet.</div>';
    html += state.faqs.map(function (f) {
      return (
        '<div class="card"><div style="font-weight:700;" class="font-ur">' + esc(f.question) + "</div>" +
        '<div class="small-muted">' + esc((f.answer || "").slice(0, 220)) + "</div>" +
        '<div class="meta-row"><button class="btn btn-danger btn-sm" data-del-f="' + f.id + '">Delete</button></div></div>'
      );
    }).join("");
    return html;
  }

  function wireTabEvents() {
    Array.prototype.forEach.call(root.querySelectorAll("[data-approve]"), function (b) {
      b.onclick = function () { api("/api/admin/questions/" + b.getAttribute("data-approve") + "/approve", { method: "POST" }).then(loadAll); };
    });
    Array.prototype.forEach.call(root.querySelectorAll("[data-reject]"), function (b) {
      b.onclick = function () { api("/api/admin/questions/" + b.getAttribute("data-reject") + "/reject", { method: "POST" }).then(loadAll); };
    });
    Array.prototype.forEach.call(root.querySelectorAll("[data-review]"), function (b) {
      b.onclick = function () { api("/api/admin/questions/" + b.getAttribute("data-review") + "/review", { method: "POST" }).then(loadAll); };
    });
    Array.prototype.forEach.call(root.querySelectorAll("[data-delete]"), function (b) {
      b.onclick = function () { if (confirm("Delete this question?")) api("/api/admin/questions/" + b.getAttribute("data-delete"), { method: "DELETE" }).then(loadAll); };
    });
    Array.prototype.forEach.call(root.querySelectorAll("[data-edit]"), function (b) {
      b.onclick = function () { openEditModal(b.getAttribute("data-edit")); };
    });
    Array.prototype.forEach.call(root.querySelectorAll("[data-del-k]"), function (b) {
      b.onclick = function () { if (confirm("Delete this source?")) api("/api/admin/knowledge/" + b.getAttribute("data-del-k"), { method: "DELETE" }).then(loadAll); };
    });
    Array.prototype.forEach.call(root.querySelectorAll("[data-del-f]"), function (b) {
      b.onclick = function () { if (confirm("Delete this FAQ?")) api("/api/admin/faqs/" + b.getAttribute("data-del-f"), { method: "DELETE" }).then(loadAll); };
    });
    var addK = document.getElementById("addKnowledge"); if (addK) addK.onclick = openAddKnowledgeModal;
    var addF = document.getElementById("addFaq"); if (addF) addF.onclick = openAddFaqModal;
  }

  function modal(html) {
    var back = document.createElement("div");
    back.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:60;display:flex;align-items:center;justify-content:center;";
    back.innerHTML = '<div style="background:var(--card);border-radius:16px;padding:1.2rem;width:90%;max-width:560px;max-height:88vh;overflow-y:auto;">' + html + "</div>";
    back.onclick = function (e) { if (e.target === back) document.body.removeChild(back); };
    document.body.appendChild(back);
    return back;
  }

  function openEditModal(id) {
    var q = state.questions.filter(function (x) { return x.id === id; })[0];
    if (!q) return;
    var m = modal(
      "<h3>Edit Answer</h3>" +
      '<div class="field-label">Short Answer</div><textarea id="edShort" rows="2" style="width:100%;">' + esc(q.shortAnswer) + "</textarea>" +
      '<div class="field-label">Explanation</div><textarea id="edExpl" rows="5" style="width:100%;">' + esc(q.explanation) + "</textarea>" +
      '<div class="field-label">Sources (one per line)</div><textarea id="edSrc" rows="3" style="width:100%;">' + esc((q.sources || []).join("\n")) + "</textarea>" +
      '<div style="display:flex;gap:.5rem;margin-top:.6rem;"><button class="btn btn-primary btn-sm" id="edSave">Save</button><button class="btn btn-outline btn-sm" id="edCancel">Cancel</button></div>'
    );
    m.querySelector("#edCancel").onclick = function () { document.body.removeChild(m); };
    m.querySelector("#edSave").onclick = function () {
      var upd = {
        shortAnswer: m.querySelector("#edShort").value,
        explanation: m.querySelector("#edExpl").value,
        sources: m.querySelector("#edSrc").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean),
      };
      api("/api/admin/questions/" + id, { method: "PUT", body: JSON.stringify(upd) }).then(function () {
        document.body.removeChild(m);
        loadAll();
      });
    };
  }

  function openAddKnowledgeModal() {
    var m = modal(
      "<h3>Add Knowledge Source</h3>" +
      '<div class="field-label">Title</div><input id="knTitle" style="width:100%;padding:.5rem;">' +
      '<div class="field-label">Content</div><textarea id="knContent" rows="6" style="width:100%;"></textarea>' +
      '<div style="display:flex;gap:.5rem;margin-top:.6rem;"><button class="btn btn-primary btn-sm" id="knSave">Save</button><button class="btn btn-outline btn-sm" id="knCancel">Cancel</button></div>'
    );
    m.querySelector("#knCancel").onclick = function () { document.body.removeChild(m); };
    m.querySelector("#knSave").onclick = function () {
      var title = m.querySelector("#knTitle").value.trim();
      var content = m.querySelector("#knContent").value.trim();
      if (!title || !content) return;
      api("/api/admin/knowledge", { method: "POST", body: JSON.stringify({ title: title, content: content }) }).then(function () {
        document.body.removeChild(m);
        loadAll();
      });
    };
  }

  function openAddFaqModal() {
    var m = modal(
      "<h3>Add FAQ</h3>" +
      '<div class="field-label">Question</div><input id="fqQ" style="width:100%;padding:.5rem;">' +
      '<div class="field-label">Answer</div><textarea id="fqA" rows="5" style="width:100%;"></textarea>' +
      '<div class="field-label">Sources (one per line)</div><textarea id="fqS" rows="2" style="width:100%;"></textarea>' +
      '<div style="display:flex;gap:.5rem;margin-top:.6rem;"><button class="btn btn-primary btn-sm" id="fqSave">Save</button><button class="btn btn-outline btn-sm" id="fqCancel">Cancel</button></div>'
    );
    m.querySelector("#fqCancel").onclick = function () { document.body.removeChild(m); };
    m.querySelector("#fqSave").onclick = function () {
      var question = m.querySelector("#fqQ").value.trim();
      var answer = m.querySelector("#fqA").value.trim();
      if (!question || !answer) return;
      var sources = m.querySelector("#fqS").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
      api("/api/admin/faqs", { method: "POST", body: JSON.stringify({ question: question, answer: answer, sources: sources }) }).then(function () {
        document.body.removeChild(m);
        loadAll();
      });
    };
  }

  api("/api/admin/me").then(loadAll).catch(function () {});
})();

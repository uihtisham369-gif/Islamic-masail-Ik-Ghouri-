# Islamic Masail – IK GHOURI

A public Islamic Q&A website: anyone can ask a question in Urdu, Arabic, or
English and get an AI-generated answer grounded in Qur'an, authentic Hadith,
and mainstream scholarly opinion, with sources shown. New AI answers go into
a **pending queue** and only appear on the public site once an admin
approves and publishes them. Admins log in separately to review, edit,
approve/reject, and mark answers "Reviewed by Scholar."

## Why this is a separate app (not the claude.ai artifact)

claude.ai's in-browser Artifacts only work for people signed in to a Claude
account inside your organization — they cannot serve anonymous public
internet visitors, and AI calls from an artifact spend *the viewer's own*
Claude usage. A truly public site needs its own server, its own database,
and your own Anthropic API key kept server-side — which is what this app is.

## Features

- Public home page with an Urdu/Arabic/English question box, no account
  required
- AI answers via the Anthropic API (key stays server-side, never sent to
  the browser)
- New answers are **pending** until an admin approves them — approved ones
  become public, searchable, and get their own SEO-friendly page
- Admin panel behind a real login (email + bcrypt-hashed password + signed,
  httpOnly JWT cookie) — never in the public frontend bundle
- "Reviewed by Scholar" toggle
- Public search, category pages, FAQ page
- Rate limiting on the ask endpoint (8 requests / 10 min / IP) plus a
  honeypot field and duplicate-submission throttle for basic spam
  protection
- SEO: server-rendered pages with per-page titles/descriptions, `sitemap.xml`,
  `robots.txt` (admin pages excluded and marked `noindex`)
- About Us, Contact, Privacy Policy, Terms, and Disclaimer pages
- Mobile-friendly, RTL-aware design

## 1. Install

```bash
npm install
```

Requires Node.js 18+ (for the built-in `fetch`).

## 2. Configure

```bash
cp .env.example .env
```

Then fill in `.env`:

- `ANTHROPIC_API_KEY` — your Anthropic API key (console.anthropic.com). This
  is only ever read on the server; it is never sent to the browser.
- `ADMIN_EMAIL` — the email the admin logs in with.
- `ADMIN_PASSWORD_HASH` — generate with:
  ```bash
  npm run hash-password
  ```
  and paste the printed hash into `.env`. Never put a plain-text password
  in `.env` or anywhere in the code.
- `JWT_SECRET` — a long random string:
  ```bash
  node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
  ```
- `SITE_URL` — your real public domain once deployed (used in canonical
  links and the sitemap).

## 3. Run locally

```bash
npm start
```

Visit `http://localhost:3000`. Admin login is at `/admin/login`.

## 4. Deploy so it's public on the internet

This is a standard Node/Express app, so it runs on any Node host:
**Render, Railway, Fly.io, a VPS, etc.** General steps (Render as an
example):

1. Push this folder to a GitHub repo (the `.gitignore` already excludes
   `.env` and `node_modules` — never commit real secrets).
2. Create a new "Web Service" on your host, connect the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. Add the environment variables from your `.env` in the host's dashboard
   (never commit `.env` itself).
5. Point your domain at the host, then set `SITE_URL` to that domain.

**Important — data persistence:** this starter stores questions/FAQs/
knowledge base entries in `data/db.json` on disk. That's fine for getting a
real public site running quickly, but on hosts with ephemeral/serverless
filesystems (or when you scale to multiple server instances) it will not
persist reliably. Before serious production use, swap `lib/store.js` for a
real database (Postgres, MySQL, SQLite with a persistent volume, etc.) —
every route only calls `readDB()`/`writeDB()`, so that's the only file you
need to change.

## 5. Security notes

- No API keys, database credentials, or admin credentials are ever sent to
  the browser — the Anthropic key and password hash live only in server
  environment variables and are used only in `server.js`.
- Admin sessions use an httpOnly, signed JWT cookie (not readable by
  JavaScript, so it isn't stealable via XSS) with a 12-hour expiry.
- `/admin` and `/admin/login` are marked `noindex, nofollow` and excluded
  from `robots.txt`; they're unlisted, not hidden by security — the real
  protection is the login check in `server.js`.
- Rate limiting is in-memory, which is fine for a single server instance;
  if you run multiple instances behind a load balancer, use a shared store
  (e.g. Redis) with `express-rate-limit` instead.
- The legal pages (Privacy Policy, Terms, Disclaimer) are starter templates,
  not legal advice — have them reviewed before you rely on them.

## 6. Content moderation model

1. A visitor asks a question → AI answers immediately and shows it to them,
   but it is saved with `status: "pending"`.
2. It does **not** appear in public search, category pages, or the sitemap
   yet.
3. An admin reviews it in `/admin`, edits it if needed, and clicks
   **Approve & Publish** (or **Reject**).
4. Only published questions are public, searchable, and get their own
   `/question/:id` page.
5. An admin (or a scholar with admin access) can additionally mark any
   question **"Reviewed by Scholar."**

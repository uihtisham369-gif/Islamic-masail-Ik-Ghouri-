require("dotenv").config();
const express = require("express");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const path = require("path");

const { readDB, writeDB } = require("./lib/store");
const { CAT_KEYS, buildPrompt } = require("./lib/categories");
const {
  renderHome, renderFaqPage, renderCategoryPage, renderQuestionPage,
  renderSearchPage, renderStaticPage, renderAdminLogin, renderAdminDashboard,
} = require("./lib/views");

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use("/static", express.static(path.join(__dirname, "public"), { maxAge: "1d" }));

const SITE_URL = (process.env.SITE_URL || "http://localhost:3000").replace(/\/$/, "");
const JWT_SECRET = process.env.JWT_SECRET;
const ADMIN_EMAIL = process.env.ADMIN_EMAIL;
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const ANTHROPIC_MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";

if (!JWT_SECRET) {
  console.warn("WARNING: JWT_SECRET is not set. Set a long random value in your .env before going live.");
}

// ---------- rate limiting & abuse protection ----------
const askLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "too_many_requests" },
});
const generalApiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, message: { error: "too_many_requests" } });
app.use("/api/", generalApiLimiter);

const recentSubmissions = new Map(); // ip -> {hash, time}
function clientIp(req) {
  return (req.headers["x-forwarded-for"] || req.ip || "").toString().split(",")[0].trim();
}
function isDuplicateSpam(ip, question) {
  const now = Date.now();
  const hash = crypto.createHash("sha256").update(question.trim().toLowerCase()).digest("hex");
  const prev = recentSubmissions.get(ip);
  recentSubmissions.set(ip, { hash, time: now });
  if (recentSubmissions.size > 5000) recentSubmissions.clear(); // basic memory cap
  return !!(prev && prev.hash === hash && now - prev.time < 60000);
}

// ---------- admin auth ----------
function requireAdmin(req, res, next) {
  const token = req.cookies && req.cookies.admin_token;
  if (!token || !JWT_SECRET) return res.status(401).json({ error: "unauthorized" });
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: "unauthorized" });
  }
}

function publicQuestion(q) {
  return {
    id: q.id, question: q.question, language: q.language, category: q.category,
    shortAnswer: q.shortAnswer, explanation: q.explanation, sources: q.sources,
    disputedNote: q.disputedNote, needsScholar: q.needsScholar, scholarReviewed: q.scholarReviewed,
    createdAt: q.createdAt,
  };
}

function extractJson(text) {
  const iBrace = text.indexOf("{");
  const iBracket = text.indexOf("[");
  const candidates = [iBrace, iBracket].filter((i) => i >= 0);
  const start = candidates.length ? Math.min(...candidates) : -1;
  const end = Math.max(text.lastIndexOf("}"), text.lastIndexOf("]"));
  if (start < 0 || end < 0) return text;
  return text.slice(start, end + 1);
}

// ================= PUBLIC API =================
app.get("/api/categories", (req, res) => res.json(require("./lib/categories").CATS));

app.get("/api/questions", (req, res) => {
  const db = readDB();
  let list = db.questions.filter((q) => q.status === "published");
  const { category, q: term } = req.query;
  if (category) list = list.filter((x) => x.category === category);
  if (term) {
    const t = String(term).toLowerCase();
    list = list.filter((x) => (x.question + " " + x.shortAnswer + " " + x.explanation).toLowerCase().indexOf(t) >= 0);
  }
  list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  res.json(list.slice(0, 200).map(publicQuestion));
});

app.get("/api/questions/:id", (req, res) => {
  const db = readDB();
  const q = db.questions.find((x) => x.id === req.params.id && x.status === "published");
  if (!q) return res.status(404).json({ error: "not_found" });
  res.json(publicQuestion(q));
});

app.get("/api/faqs", (req, res) => res.json(readDB().faqs));

app.post("/api/ask", askLimiter, async (req, res) => {
  try {
    const { question, language, category, website } = req.body || {};
    if (website) return res.status(400).json({ error: "invalid_request" }); // honeypot field
    if (!question || typeof question !== "string" || question.trim().length < 5 || question.length > 2000) {
      return res.status(400).json({ error: "invalid_question" });
    }
    const lang = ["ur", "ar", "en"].includes(language) ? language : "ur";
    const ip = clientIp(req);
    if (isDuplicateSpam(ip, question)) return res.status(429).json({ error: "duplicate" });
    if (!ANTHROPIC_API_KEY) return res.status(503).json({ error: "ai_unavailable" });

    const db = readDB();
    const prompt = buildPrompt({ question: question.trim(), lang, knowledge: db.knowledge, preferredCat: category });

    const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: ANTHROPIC_MODEL,
        max_tokens: 1200,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!aiRes.ok) {
      const errText = await aiRes.text().catch(() => "");
      console.error("Anthropic API error", aiRes.status, errText);
      return res.status(502).json({ error: "ai_error" });
    }
    const data = await aiRes.json();
    const textBlock = (data.content || []).find((b) => b.type === "text");
    if (!textBlock) return res.status(502).json({ error: "ai_empty" });

    let parsed;
    try {
      parsed = JSON.parse(extractJson(textBlock.text));
    } catch (e) {
      return res.status(502).json({ error: "ai_parse_error" });
    }

    const cat = CAT_KEYS.includes(parsed.categoryKey) ? parsed.categoryKey : "عمومی اسلامی سوالات";
    const doc = {
      id: crypto.randomUUID(),
      question: question.trim(),
      language: lang,
      category: cat,
      shortAnswer: String(parsed.shortAnswer || ""),
      explanation: String(parsed.explanation || ""),
      sources: Array.isArray(parsed.sources) ? parsed.sources.map(String) : [],
      disputedNote: parsed.disputedNote ? String(parsed.disputedNote) : null,
      needsScholar: !!parsed.needsScholar,
      scholarReviewed: false,
      status: "pending", // an admin must approve before this appears in public search/listings
      createdAt: new Date().toISOString(),
    };
    db.questions.push(doc);
    await writeDB(db);
    res.json(publicQuestion(doc));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "server_error" });
  }
});

// ================= ADMIN AUTH =================
app.post("/api/admin/login", loginLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD_HASH || !JWT_SECRET) {
    return res.status(503).json({ error: "admin_not_configured" });
  }
  if (email !== ADMIN_EMAIL) return res.status(401).json({ error: "invalid_credentials" });
  const ok = await bcrypt.compare(password || "", ADMIN_PASSWORD_HASH);
  if (!ok) return res.status(401).json({ error: "invalid_credentials" });
  const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: "12h" });
  res.cookie("admin_token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 12 * 60 * 60 * 1000,
  });
  res.json({ ok: true });
});
app.post("/api/admin/logout", (req, res) => {
  res.clearCookie("admin_token");
  res.json({ ok: true });
});
app.get("/api/admin/me", requireAdmin, (req, res) => res.json({ email: req.admin.email }));

// ================= ADMIN API =================
app.get("/api/admin/questions", requireAdmin, (req, res) => {
  const db = readDB();
  res.json(db.questions.slice().sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || "")));
});
app.put("/api/admin/questions/:id", requireAdmin, async (req, res) => {
  const db = readDB();
  const q = db.questions.find((x) => x.id === req.params.id);
  if (!q) return res.status(404).json({ error: "not_found" });
  const { shortAnswer, explanation, sources, category, disputedNote } = req.body || {};
  if (shortAnswer !== undefined) q.shortAnswer = String(shortAnswer);
  if (explanation !== undefined) q.explanation = String(explanation);
  if (Array.isArray(sources)) q.sources = sources.map(String);
  if (category && CAT_KEYS.includes(category)) q.category = category;
  if (disputedNote !== undefined) q.disputedNote = disputedNote || null;
  await writeDB(db);
  res.json(q);
});
async function setStatus(id, status, res) {
  const db = readDB();
  const q = db.questions.find((x) => x.id === id);
  if (!q) return res.status(404).json({ error: "not_found" });
  q.status = status;
  await writeDB(db);
  res.json(q);
}
app.post("/api/admin/questions/:id/approve", requireAdmin, (req, res) => setStatus(req.params.id, "published", res));
app.post("/api/admin/questions/:id/reject", requireAdmin, (req, res) => setStatus(req.params.id, "rejected", res));
app.post("/api/admin/questions/:id/review", requireAdmin, async (req, res) => {
  const db = readDB();
  const q = db.questions.find((x) => x.id === req.params.id);
  if (!q) return res.status(404).json({ error: "not_found" });
  q.scholarReviewed = !q.scholarReviewed;
  await writeDB(db);
  res.json(q);
});
app.delete("/api/admin/questions/:id", requireAdmin, async (req, res) => {
  const db = readDB();
  db.questions = db.questions.filter((x) => x.id !== req.params.id);
  await writeDB(db);
  res.json({ ok: true });
});

app.get("/api/admin/knowledge", requireAdmin, (req, res) => res.json(readDB().knowledge));
app.post("/api/admin/knowledge", requireAdmin, async (req, res) => {
  const { title, content, category } = req.body || {};
  if (!title || !content) return res.status(400).json({ error: "invalid" });
  const db = readDB();
  const item = { id: crypto.randomUUID(), title: String(title), content: String(content), category: CAT_KEYS.includes(category) ? category : null, addedAt: new Date().toISOString() };
  db.knowledge.push(item);
  await writeDB(db);
  res.json(item);
});
app.delete("/api/admin/knowledge/:id", requireAdmin, async (req, res) => {
  const db = readDB();
  db.knowledge = db.knowledge.filter((x) => x.id !== req.params.id);
  await writeDB(db);
  res.json({ ok: true });
});

app.post("/api/admin/faqs", requireAdmin, async (req, res) => {
  const { question, answer, sources } = req.body || {};
  if (!question || !answer) return res.status(400).json({ error: "invalid" });
  const db = readDB();
  const item = { id: crypto.randomUUID(), question: String(question), answer: String(answer), sources: Array.isArray(sources) ? sources.map(String) : [], addedAt: new Date().toISOString() };
  db.faqs.push(item);
  await writeDB(db);
  res.json(item);
});
app.delete("/api/admin/faqs/:id", requireAdmin, async (req, res) => {
  const db = readDB();
  db.faqs = db.faqs.filter((x) => x.id !== req.params.id);
  await writeDB(db);
  res.json({ ok: true });
});

// ================= PAGES (SSR + SEO) =================
app.get("/", (req, res) => res.send(renderHome({ SITE_URL })));
app.get("/faq", (req, res) => res.send(renderFaqPage({ SITE_URL, faqs: readDB().faqs })));
app.get("/search", (req, res) => res.send(renderSearchPage({ SITE_URL })));
app.get("/category/:key", (req, res) => {
  const key = req.params.key;
  const questions = readDB().questions.filter((q) => q.status === "published" && q.category === key);
  res.send(renderCategoryPage({ SITE_URL, key, questions }));
});
app.get("/question/:id", (req, res) => {
  const q = readDB().questions.find((x) => x.id === req.params.id && x.status === "published");
  if (!q) return res.status(404).send(renderStaticPage({ SITE_URL, slug: "not-found" }));
  res.send(renderQuestionPage({ SITE_URL, q }));
});
["about", "contact", "privacy", "terms", "disclaimer"].forEach((slug) => {
  app.get("/" + slug, (req, res) => res.send(renderStaticPage({ SITE_URL, slug })));
});
app.get("/admin/login", (req, res) => res.send(renderAdminLogin({ SITE_URL })));
app.get("/admin", (req, res) => res.send(renderAdminDashboard({ SITE_URL })));

app.get("/robots.txt", (req, res) => {
  res.type("text/plain").send(`User-agent: *\nAllow: /\nDisallow: /admin\nSitemap: ${SITE_URL}/sitemap.xml\n`);
});
app.get("/sitemap.xml", (req, res) => {
  const db = readDB();
  const staticUrls = ["", "faq", "search", "about", "contact", "privacy", "terms", "disclaimer", ...CAT_KEYS.map((k) => "category/" + encodeURIComponent(k))];
  const qUrls = db.questions.filter((q) => q.status === "published").slice(0, 1000).map((q) => "question/" + q.id);
  const urls = [...staticUrls, ...qUrls];
  const xml =
    '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' +
    urls.map((u) => "<url><loc>" + SITE_URL + "/" + u + "</loc></url>").join("") +
    "</urlset>";
  res.type("application/xml").send(xml);
});

app.use((req, res) => res.status(404).send(renderStaticPage({ SITE_URL, slug: "not-found" })));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Islamic Masail server running on port " + PORT));
